package com.example.ep1_evaluacion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Artista(
    val nombre: String,
    val imagen: Int
)

data class Cancion(
    val titulo: String,
    val artista: String
)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                PantallaMusica()
            }
        }
    }
}

@Composable
fun PantallaMusica() {

    val artistas = listOf(
        Artista(
            "Natanael Cano",
            R.drawable.natanael_cano
        ),
        Artista(
            "Junior H",
            R.drawable.junior_h
        ),
        Artista(
            "Peso Pluma",
            R.drawable.peso_pluma
        ),
        Artista(
            "Eslabón Armado",
            R.drawable.eslabon_armado
        ),
        Artista(
            "Bad Bunny",
            R.drawable.bad_bunny
        ),
        Artista(
            "A Boogie",
            R.drawable.a_boogie
        ),
        Artista(
            "YNG LVCAS",
            R.drawable.yng_lvcas
        ),
        Artista(
            "Feid",
            R.drawable.feid
        )
    )

    val canciones = listOf(
        Cancion(
            "Amor Tumbado",
            "Natanael Cano"
        ),
        Cancion(
            "PRC",
            "Peso Pluma & Natanael Cano"
        ),
        Cancion(
            "Ella Baila Sola",
            "Eslabón Armado & Peso Pluma"
        ),
        Cancion(
            "El Azul",
            "Junior H & Peso Pluma"
        ),
        Cancion(
            "Lady Gaga",
            "Peso Pluma"
        ),
        Cancion(
            "Qué Bendición",
            "Natanael Cano"
        ),
        Cancion(
            "Baile Inolvidable",
            "Bad Bunny"
        ),
        Cancion(
            "DÁKITI",
            "Bad Bunny & Jhay Cortez"
        ),
        Cancion(
            "GATITAS SANDUNGUERAS",
            "Álvaro Díaz & Feid"
        ),
        Cancion(
            "Me Muevo",
            "YNG LVCAS"
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(15.dp)
    ) {

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(145.dp),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFEDEDED)
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 0.dp
            )
        ) {

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {

                androidx.compose.foundation.Image(
                    painter = painterResource(
                        id = R.drawable.natanael_cano
                    ),
                    contentDescription = "Natanael Cano",
                    modifier = Modifier
                        .size(70.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )

                Spacer(
                    modifier = Modifier.width(12.dp)
                )

                Column(
                    modifier = Modifier.weight(1f)
                ) {

                    Text(
                        text = "Natanael Cano",
                        fontSize = 14.sp
                    )

                    Spacer(
                        modifier = Modifier.height(5.dp)
                    )

                    Text(
                        text = "Exponente de los corridos tumbados.\nConoce sus canciones más populares.",
                        fontSize = 9.sp
                    )

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {

                        OutlinedButton(
                            onClick = {},
                            modifier = Modifier.height(29.dp),
                            shape = RoundedCornerShape(15.dp),
                            border = BorderStroke(
                                1.dp,
                                Color(0xFFD0D0D0)
                            ),
                            contentPadding = ButtonDefaults.ContentPadding
                        ) {

                            Text(
                                text = "Perfil",
                                fontSize = 9.sp
                            )
                        }

                        Spacer(
                            modifier = Modifier.width(7.dp)
                        )

                        Button(
                            onClick = {},
                            modifier = Modifier.height(29.dp),
                            shape = RoundedCornerShape(15.dp),
                            contentPadding = ButtonDefaults.ContentPadding
                        ) {

                            Text(
                                text = "Escuchar",
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }
        }

        Spacer(
            modifier = Modifier.height(20.dp)
        )

        Text(
            text = "Artistas",
            fontSize = 14.sp
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            items(artistas) { artista ->

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    androidx.compose.foundation.Image(
                        painter = painterResource(
                            id = artista.imagen
                        ),
                        contentDescription = artista.nombre,
                        modifier = Modifier
                            .size(58.dp)
                            .clip(
                                RoundedCornerShape(10.dp)
                            ),
                        contentScale = ContentScale.Crop
                    )

                    Spacer(
                        modifier = Modifier.height(4.dp)
                    )

                    Text(
                        text = artista.nombre,
                        fontSize = 8.sp
                    )
                }
            }
        }

        Spacer(
            modifier = Modifier.height(18.dp)
        )

        Text(
            text = "Canciones",
            fontSize = 14.sp
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {

            items(canciones) { cancion ->

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(
                            RoundedCornerShape(9.dp)
                        )
                        .background(
                            Color(0xFFD8D8D8)
                        )
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.CenterStart
                ) {

                    Column {

                        Text(
                            text = cancion.titulo,
                            fontSize = 11.sp
                        )

                        Text(
                            text = cancion.artista,
                            fontSize = 8.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }
        }
    }
}
package com.example.retrofit_demo.ui.theme.data

data class Post(
    val userId: Int,
    val id: Int,
    val title: String,
    val body: String
)
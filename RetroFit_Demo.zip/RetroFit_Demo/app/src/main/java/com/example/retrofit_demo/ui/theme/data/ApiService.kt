package com.example.retrofit_demo.ui.theme.data

import retrofit2.http.GET

interface ApiService {

    @GET("Posts")
    suspend fun getPosts(): List<Post>
}